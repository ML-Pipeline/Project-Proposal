### Applied analytics: machine learning pipeline course

The repository contains template LaTeX files for the proposal and the paper. Further instructions are contained within each document.
